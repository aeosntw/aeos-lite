self.__uv$config = {
	prefix: "/prox/uv/run/",
	bare: "https://v2202412246404304352.megasrv.de/bare/",
	encodeUrl: Ultraviolet.codec.xor.encode,
	decodeUrl: Ultraviolet.codec.xor.decode,
	handler: "/prox/uv/uv/uv.handler.js",
	bundle: "/prox/uv/uv/uv.bundle.js",
	config: "/prox/uv/uv/uv.config.js",
	sw: "/prox/uv/uv/uv.sw.js",
};
